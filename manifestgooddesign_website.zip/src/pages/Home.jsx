import React from "react";

function Home() {
  return <h1>Welcome to Manifest Good Design</h1>;
}

export default Home;