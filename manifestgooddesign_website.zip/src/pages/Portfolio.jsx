import React from "react";

function Portfolio() {
  return <h1>Portfolio</h1>;
}

export default Portfolio;